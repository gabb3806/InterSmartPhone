package com.capston.andro.sip;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    static final int REQUEST_ENABLE_BT = 10;
    private static final int REQUEST_CONNECT_DEVICE = 1;

    // 폰의 블루투스 모듈을 사용하기 위한 오브젝트.
    BluetoothAdapter mBluetoothAdapter;
    /**
     BluetoothDevice 로 기기의 장치정보를 알아낼 수 있는 자세한 메소드 및 상태값을 알아낼 수 있다.
     연결하고자 하는 다른 블루투스 기기의 이름, 주소, 연결 상태 등의 정보를 조회할 수 있는 클래스.
     현재 기기가 아닌 다른 블루투스 기기와의 연결 및 정보를 알아낼 때 사용.
     */

    private Handler mHandler;

    private String recivemsg;
    private String recivemsg2;

    private ConnectedTask mConnectedTask = null;
    private String mConnectedDeviceName = null;
    static boolean isConnectionError = false;
    private static final String TAG = "BluetoothClient";
    private TextView mConnectionStatus;
    private Button capture;
    private Button btn_open;
    private Button btn_close;
    private Button pwd_change;
    private Button btn_call;
    private Button btn_siren;
    private Switch blue_switch;
    private WebView webView;
    private LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        mHandler = new Handler();
        mConnectionStatus = (TextView)findViewById(R.id.connection_status_textview);
        capture=(Button)findViewById(R.id.capture);
        webView = (WebView) findViewById(R.id.wv_stream);
        container = (LinearLayout)findViewById(R.id.main_container);
        btn_open=(Button)findViewById(R.id.open_btn);
        btn_close=(Button)findViewById(R.id.close_btn);
        pwd_change=(Button)findViewById(R.id.pwd_change);
        btn_call=(Button)findViewById(R.id.call_btn);
        btn_siren=(Button)findViewById(R.id.siren_btn);
        blue_switch=(Switch)findViewById(R.id.blueswitch);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        String url ="http://라즈베리파이ip:8080/stream";
        webView.loadUrl(url);

        blue_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                 if (isChecked == true){
                     getDeviceState();
                 }else{
                     mBluetoothAdapter.disable();
                     Toast.makeText(getApplicationContext(), "블루투스를 해제합니다.", Toast.LENGTH_SHORT).show();
                 }
             }
         });

        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String folder = "InterPhone"; // 폴더 이름
                try {
                    // 현재 날짜로 파일을 저장하기
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
                    // 년월일시분초
                    Date currentTime_1 = new Date();
                    String dateString = formatter.format(currentTime_1);
                    File sdCardPath = Environment.getExternalStorageDirectory();
                    File dirs = new File(Environment.getExternalStorageDirectory(), folder);

                    if (!dirs.exists()) { // 원하는 경로에 폴더가 있는지 확인
                        dirs.mkdirs(); // Test 폴더 생성
                        Log.d("CAMERA_TEST", "Directory Created");
                    }
                    container.setDrawingCacheEnabled(true);
                    container.buildDrawingCache();
                    Bitmap captureView = container.getDrawingCache();

                    FileOutputStream fos;
                    String save;
                    try {
                        save = sdCardPath.getPath() + "/" + folder + "/" + dateString + ".jpg";
                        // 저장 경로
                        fos = new FileOutputStream(save);
                        captureView.compress(Bitmap.CompressFormat.JPEG, 100, fos); // 캡쳐
                        // 미디어 스캐너를 통해 모든 미디어 리스트를 갱신시킨다.
                        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                Uri.parse("file://" + Environment.getExternalStorageDirectory())));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), dateString + ".jpg 저장",
                            Toast.LENGTH_LONG).show();
                    container.setDrawingCacheEnabled(false);
                } catch (Exception e) {
                    // TODO: handle exception
                    Log.e("Screen", "" + e.toString());
                }
            }
        });
        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                startActivity(intent);
            }
        });
        btn_siren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call();
            }
        });
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mBluetoothAdapter.isEnabled()) { // 블루투스 지원하며 비활성 상태인 경우.
                    Toast.makeText(getApplicationContext(), "블루투스를 연결하세요.", Toast.LENGTH_SHORT).show();
                }
                else // 블루투스 지원하며 활성 상태인 경우.
                show();
            }
        });
        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mBluetoothAdapter.isEnabled()) { // 블루투스 지원하며 비활성 상태인 경우.
                    Toast.makeText(getApplicationContext(), "블루투스를 연결하세요.", Toast.LENGTH_SHORT).show();
                }
                else { // 블루투스 지원하며 활성 상태인 경우.
                    sendMessage("close");
                    Toast.makeText(getApplicationContext(), "문이 닫힙니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        pwd_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mBluetoothAdapter.isEnabled()) { // 블루투스 지원하며 비활성 상태인 경우.
                    Toast.makeText(getApplicationContext(), "블루투스를 연결하세요.", Toast.LENGTH_SHORT).show();
                }
                else { // 블루투스 지원하며 활성 상태인 경우.
                    sendMessage("change");
                    show2();
                }
            }
        });
    }

    void getDeviceState() {
        Log.d(TAG, "Check the Bluetooth support");

        if(mBluetoothAdapter == null) {
            Log.d(TAG, "Bluetooth is not available");
            Toast.makeText(getApplicationContext(), "기기가 블루투스를 지원하지 않습니다.", Toast.LENGTH_LONG).show();
            finish();
        }
        else {
            if(mBluetoothAdapter.isEnabled()) {
                // 기기의 블루투스 상태가 On인 경우
                Log.d(TAG, "Bluetooth Enable Now");
                Intent serverIntent = new Intent(MainActivity.this, DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
            } else {
                // 기기의 블루투스 상태가 Off인 경우
                Log.d(TAG, "Bluetooth Enable Request");

                Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(i, REQUEST_ENABLE_BT);
            }
        }
    }

    public void scanDevice() {
        Log.d(TAG, "Scan Device");
        Intent serverIntent = new Intent(MainActivity.this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
    }
    public void getDeviceInfo(Intent data)
    {
        String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        Log.d(TAG, "Get Device Info \n" + "address : " + address);
        ConnectTask task = new ConnectTask(device);
        task.execute();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:
                if (resultCode == Activity.RESULT_OK) {
                    getDeviceInfo(data);
                }
                break;
            case REQUEST_ENABLE_BT:
                if (resultCode == Activity.RESULT_OK) {
                    scanDevice();
                } else {
                    Log.d(TAG, "Bluetooth is not enabled");
                }
                break;
        }
    }

    private class ConnectTask extends AsyncTask<Void, Void, Boolean> {

        private BluetoothSocket mBluetoothSocket = null;
        private BluetoothDevice mBluetoothDevice = null;

        ConnectTask(BluetoothDevice bluetoothDevice) {
            mBluetoothDevice = bluetoothDevice;
            mConnectedDeviceName = bluetoothDevice.getName();
            //SPP
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

            try {
                mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(uuid);
                Log.d( TAG, "create socket for "+mConnectedDeviceName);

            } catch (IOException e) {
                Log.e( TAG, "socket create failed " + e.getMessage());
            }
        }
        @Override
        protected Boolean doInBackground(Void... params) {

            mBluetoothAdapter.cancelDiscovery();

            try {
                mBluetoothSocket.connect();
            } catch (IOException e) {
                // Close the socket
                try {
                    mBluetoothSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() " +
                            " socket during connection failure", e2);
                }
                return false;
            }
            return true;
        }
        @Override
        protected void onPostExecute(Boolean isSucess) {

            if ( isSucess ) {
                connected(mBluetoothSocket);
            }
            else{
                isConnectionError = true;
                Log.d( TAG,  "Unable to connect device");
                Toast.makeText(getApplicationContext(), "장치에 연결할 수 없습니다.", Toast.LENGTH_LONG).show();
                finish(); // App 종료.
            }
        }
    }
    public void connected( BluetoothSocket socket ) {
        mConnectedTask = new ConnectedTask(socket);
        mConnectedTask.execute();
    }
    private class ConnectedTask extends AsyncTask<Void, String, Boolean> {

        private InputStream mInputStream = null;
        private OutputStream mOutputStream = null;
        private BluetoothSocket mBluetoothSocket = null;

        ConnectedTask(BluetoothSocket socket){

            mBluetoothSocket = socket;
            try {
                mInputStream = mBluetoothSocket.getInputStream();
                mOutputStream = mBluetoothSocket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "socket not created", e );
            }
            Log.d( TAG, "connected to "+mConnectedDeviceName);
            mConnectionStatus.setText(mConnectedDeviceName);
        }

        @Override
        protected Boolean doInBackground(Void... params) {

            byte [] readBuffer = new byte[1024];
            int readBufferPosition = 0;


            while (true) {
                if ( isCancelled() ) {
                    return false;
                }
                try {
                    int bytesAvailable = mInputStream.available();
                    if(bytesAvailable > 0) {
                        byte[] packetBytes = new byte[bytesAvailable];
                        mInputStream.read(packetBytes);
                        for(int i=0;i<bytesAvailable;i++) {
                            byte b = packetBytes[i];
                            if(b == '\n')
                            {
                                byte[] encodedBytes = new byte[readBufferPosition];
                                System.arraycopy(readBuffer, 0, encodedBytes, 0,
                                        encodedBytes.length-1);
                                String recvMessage = new String(encodedBytes, "UTF-8");
                                readBufferPosition = 0;
                                Log.d(TAG, "recv message: " + recvMessage);
                                publishProgress(recvMessage);
                            }
                            else
                            {
                                readBuffer[readBufferPosition++] = b;
                            }
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "disconnected", e);
                    return false;
                }
            }
        }
        @Override
        protected void onProgressUpdate(String... recvMessage)
        {
            onString(recvMessage[0]);
        }

        @Override
        protected void onPostExecute(Boolean isSucess) {
            super.onPostExecute(isSucess);

            if ( !isSucess ) {


                closeSocket();
                Log.d(TAG, "Device connection was lost");
                isConnectionError = true;
                Toast.makeText(getApplicationContext(), "장치에 연결할 수 없습니다.", Toast.LENGTH_LONG).show();
                finish(); // App 종료.
            }
        }

        void closeSocket(){

            try {

                mBluetoothSocket.close();
                Log.d(TAG, "close socket()");

            } catch (IOException e2) {

                Log.e(TAG, "unable to close() " +
                        " socket during connection failure", e2);
            }
        }
        void write(String msg){

            try {
                mOutputStream.write(msg.getBytes());
                mOutputStream.flush();
            } catch (IOException e) {
                Log.e(TAG, "Exception during send", e );
            }
        }
    }
    void sendMessage(String msg){

        if ( mConnectedTask != null ) {
            mConnectedTask.write(msg);
            Log.d(TAG, "send message: " + msg);
        }
    }
    protected void onString(String msg) {
        recivemsg = msg;
        recivemsg2 = recivemsg.substring(0,recivemsg.length()-1);
        switch (recivemsg2){
            case "1":
                Toast.makeText(getApplicationContext(), "문이 열립니다.", Toast.LENGTH_SHORT).show();
                break;
            case "3":
                show3();
                break;
            case "4":
                show4();
                break;
            case "5":
                Toast.makeText(getApplicationContext(), "5회를 초과하였습니다.", Toast.LENGTH_SHORT).show();
                break;
            case "6":
                Toast.makeText(getApplicationContext(), "비밀번호 오류", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    void show()
    {
        final EditText edittext = new EditText(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("도어락 열기");
        builder.setMessage("비밀번호를 입력하세요.");
        builder.setView(edittext);
        builder.setPositiveButton("입력",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String sendMessage = edittext.getText().toString();
                        if (sendMessage.length() > 0) {
                            sendMessage(sendMessage);
                            edittext.setText("");
                        }
                    }
                }
        );
        builder.setNegativeButton("취소",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        builder.show();
    }
    void show2()
    {
        final EditText edittext = new EditText(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("비밀번호 변경하기");
        builder.setMessage("현재 비밀번호를 입력하세요.");
        builder.setView(edittext);
        builder.setPositiveButton("입력",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String sendMessage = edittext.getText().toString();
                        if (sendMessage.length() > 0) {
                            sendMessage(sendMessage);
                            edittext.setText("");
                        }
                    }
                }
        );
        builder.setNegativeButton("취소",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        sendMessage("stop");
                    }
                });
        builder.show();
    }
    void show3()
    {
        final EditText edittext = new EditText(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("비밀번호 변경하기");
        builder.setMessage("새로운 비밀번호를 입력하세요.");
        builder.setView(edittext);
        builder.setPositiveButton("입력",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String sendMessage = edittext.getText().toString();
                        if (sendMessage.length() > 0) {
                            sendMessage(sendMessage);
                            edittext.setText("");
                            Toast.makeText(getApplicationContext(), "비밀번호가 변경되었습니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
        builder.show();
    }
    void show4()
    {
        final EditText edittext = new EditText(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("비밀번호 변경하기");
        builder.setMessage("비밀번호가 틀렸습니다. 다시 입력하세요.");
        builder.setView(edittext);
        builder.setPositiveButton("입력",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String sendMessage = edittext.getText().toString();
                        if (sendMessage.length() > 0) {
                            sendMessage(sendMessage);
                            edittext.setText("");
                        }
                    }
                }
        );
        builder.setNegativeButton("취소",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        sendMessage("stop");
                    }
                });
        builder.show();
    }
    void call(){
        AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
        alt_bld.setMessage("정말 신고하시겠습니까?").setCancelable(
                false).setPositiveButton("예",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                            int permissionResult = checkSelfPermission(Manifest.permission.CALL_PHONE);

                            if ( permissionResult == PackageManager.PERMISSION_DENIED ){
                                if( shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE) ){
                                    AlertDialog.Builder per_dialog = new AlertDialog.Builder(MainActivity.this);
                                    per_dialog.setTitle("권한이 필요합니다.")
                                            .setMessage("이 기능을 사용하기 위해서는 단말기의 \"전화걸기\" 권한이 필요합니다. 계속하시겠습니까?")
                                            .setPositiveButton("네", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ) {
                                                        requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1000);
                                                    }
                                                }
                                            })
                                            .setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Toast.makeText(MainActivity.this,"기능을 취소했습니다.", Toast.LENGTH_SHORT).show();
                                                }
                                            }).create().show();
                                }
                                else{
                                    requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1000);
                                }
                            }
                            else{
                                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:112"));
                                startActivity(intent);
                            }
                        }
                        else {
                            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:112"));
                            startActivity(intent);
                        }
                    }
                }).setNegativeButton("아니요",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = alt_bld.create();
        alert.setTitle("긴급신고");
        alert.show();
    }
}
